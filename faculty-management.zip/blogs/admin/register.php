<?php
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">ADD ADMIN DATA</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="code.php" method="POST">

        <div class="modal-body">

            <div class="form-group">
                <label> Username </label>
                <input type="text" name="username" class="form-control" placeholder="Enter Username">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter Email">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter Password">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirmpassword" class="form-control" placeholder="Confirm Password">
            </div>
            
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Admin Profile 
            <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#addadminprofile">
              Add New Admin Profile 
            </button>
    </h6>
  </div>

  <div class="card-body">

    <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
      echo '<h4>'.$_SESSION['success'].'</h4>';
      unset($_SESSION['success']);
    }
    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
      echo '<h4 class= bg-info>'.$_SESSION['status'].'</h4>';
      unset($_SESSION['status']);
    }
    ?>

    <div class="table-responsive">

       
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID </th>
            <th> Username </th>
            <th> Email </th>
            <th> Password </th>
            <th> User Type </th>
            <th> EDIT </th>
            <th> DELETE </th>
          </tr>
        </thead>
        <tbody>

      <?php 

        $limit = 5;        
        
        if(isset($_GET['page']))
        {
          $page = $_GET['page'];
        }
        else
        {
          $page = 1;
        }
        $offset = ($page - 1) * $limit;  

        $query = "SELECT * FROM register LIMIT {$offset},{$limit}";
        $query_run = mysqli_query($con, $query);
           
     if(mysqli_num_rows($query_run) > 0)
      {
        while ($row = mysqli_fetch_assoc($query_run))
        {
    ?>
        <tr>
          <td> <?php echo $row['id']; ?></td>
          <td> <?php echo $row['username']; ?></td>
          <td> <?php echo $row['email']; ?></td>
          <td> <?php echo $row['password']; ?></td>
          <td> <?php echo $row['usertype']; ?></td>
          
          <td>
            <form action="register_edit.php" method="post">
            <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
            <button  type="submit" name="edit_btn" class="btn btn-success"> EDIT</button>
            </form>
          </td>

          <td>
            <form action="code.php" method="post">
            <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
            <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
            </form>
          </td>
        </tr>

        <?php 
        }
      }
      else
      {
        echo "No Record Found";
      }
        ?>     
        
        </tbody>
      </table>
      <?php
        $query1 = "SELECT * FROM register";
        $query_run1 = mysqli_query($con, $query1) or die("Query Failed.");

      if(mysqli_num_rows($query_run1) > 0 ){

        $total_records = mysqli_num_rows($query_run1);
        
        $total_page = ceil($total_records/$limit);

        echo '<nav aria-label="Page navigation example" class="float-middle">';
        echo '<ul class="pagination justify-content-center">';

        if($page > 1)
          {
          echo '<li class="page-item"><a class="page-link" href="register.php?page='.($page - 1).'">Previous</a></li>';
          }
        for($i =1; $i <= $total_page; $i++){
          if($i== $page)
          {
            $active = "active";
          }
          else
          {
            $active = "";
          }
          echo '<li class="'.$active.' page-item"><a class="page-link" href="register.php?page='.$i.'">'.$i.'</a></li>';
        }
        if($total_page > $page)
        {
        echo '<li class="page-item"><a class="page-link" href="register.php?page='.($page + 1).'">Next</a></li>';
        }
      echo '</ul>';
      echo '</nav>';
      }
      ?>

     
          <!--<li class="page-item"><a class="page-link" href="#">Previous</a></li>
          <li class="page-item"><a class="page-link" href="#">1</a></li>
          <li class="page-item"><a class="page-link" href="#">2</a></li>
          <li class="page-item"><a class="page-link" href="#">3</a></li>
          <li class="page-item"><a class="page-link" href="#">Next</a></li>-->
       

    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>