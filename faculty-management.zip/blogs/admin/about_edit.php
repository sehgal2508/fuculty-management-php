<?php
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php');
?>


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary"> About Us Page Edit</h6>
  </div>

  <div class="card-body">

 <?php	

if(isset($_POST['edit_btn']))
	{
	$id = $_POST['edit_id'];
	//echo $id;
   	$query = "SELECT * FROM aboutus WHERE id='$id' ";
   	$query_run = mysqli_query($con, $query);

   		foreach ($query_run as $row) 
   		{
   			?>  
   			<form action="code.php" method="POST">

          <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>" >
          
			<div class="form-group">
                <label> Title </label>
                <input type="text" name="edit_title" value="<?php echo $row['title'] ?>"class="form-control" placeholder="Enter Username">
            </div>
            <div class="form-group">
                <label>Sub-Title</label>
                <input type="text" name="edit_subtitle" value="<?php echo $row['subtitle'] ?>" class="form-control" placeholder="Enter Sub-Title">
            </div>
            <div class="form-group">
                <label>Description</label>
                <input type="text" name="edit_descs" value="<?php echo $row['descs'] ?>" class="form-control" placeholder="Enter Description">
            </div>
             <div class="form-group">
                <label>Links</label>
                <input type="text" name="edit_links" value="<?php echo $row['links'] ?>" class="form-control" placeholder="Enter Links">
            </div>
            <div>
                <a href ="aboutus.php" class="btn btn-danger"> CANCEL </button> </a>	
                <button type="submit" name="update_btn"class="btn btn-primary"> UPDATE </button>
            </div>
        <?php
   		}
	}		
?>

	   
   
    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->



<?php
include('includes/scripts.php');
include('includes/footer.php');
?>