<?php
include('security.php');

// CODE FOR USER REGISTRATION
if(isset($_POST['registerbtn']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];
    $usertype = $_POST['usertype'];

    if($password === $cpassword)
        {
            $query = "INSERT INTO register (username,email,password,usertype) VALUES ('$username','$email','$password','$usertype')";
            $query_run = mysqli_query($con, $query);
            
            if($query_run)
            {
                // echo "Saved";
                $_SESSION['success'] = "Admin Profile Added";
                header('Location: register.php');
            }
            else 
            {
                $_SESSION['status'] = "Admin Profile Not Added";
                header('Location: register.php');  
            }
        }
        else 
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            header('Location: register.php');  
        }
    }






// CODE FOR USER UPDATE
if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $password = $_POST['edit_password'];
    $password = $_POST['edit_password'];
    $usertypeupdate = $_POST['update_usertype'];

    $query = "UPDATE register SET username='$username' , email='$email', password='$password', usertype='$usertypeupdate' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is updated";
        header('Location: register.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT updated";
        header('Location: register.php');
    }
}






// CODE FOR USER DELETE
if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];
 
    $query = "DELETE FROM register WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Deleted";
        header('Location: register.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Deleted";
        header('Location: register.php');
    }
}






// CODE FOR ABOUT TITLE

if(isset($_POST['about_save']))
{
    $title = $_POST['title'];
    $subtitle = $_POST['subtitle'];
    $descs = $_POST['descs'];
    $links = $_POST['links'];

    $query = "INSERT INTO aboutus (title,subtitle,descs,links) VALUES ('$title','$subtitle','$descs','$links')";
    $query_run = mysqli_query($con, $query);
            
    if($query_run)
        {
        // echo "Saved";
        $_SESSION['success'] = "Abuout us Added.";
        header('Location: aboutus.php');
        }
        else 
        {
        $_SESSION['status'] = "About us NOT Added.";
        header('Location: aboutus.php');  
        }
}
        





// CODE FOR ABOUT TITLE UPDATE
if(isset($_POST['update_btn']))
{
    $id = $_POST['edit_id'];
    $title = $_POST['edit_title'];
    $subtitle = $_POST['edit_subtitle'];
    $descs = $_POST['edit_descs'];
    $links = $_POST['edit_links'];
    

    $query = "UPDATE aboutus SET title='$title', subtitle='$subtitle', descs='$descs', links='$links' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is updated";
        header('Location: aboutus.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT updated";
        header('Location: aboutus.php');
    }
}






// CODE FOR ABOUT TITLE DELETE
if(isset($_POST['about_delete_btn']))
{
    $id = $_POST['delete_id'];
 
    $query = "DELETE FROM aboutus WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Deleted";
        header('Location: register.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Deleted";
        header('Location: register.php');
    }
}





//CODE FOR FACULTY REGISTRATION

if(isset($_POST['save_faculty']))
{
    $name = $_POST['faculty_name'];
    $design = $_POST['faculty_design'];
    $descs = $_POST['faculty_descs'];
    $images = $_FILES['faculty_image']['name'];

    //$validation_img_extension =  $_FILES['faculty_image']['type']=="image/jpg" ||
    //$_FILES['faculty_image']['type']=="image/png" ||
    //$_FILES['faculty_image']['type']=="image/jpeg" 
    //;

    $img_types = array('image/jpg','image/jpeg','image/png');
    $validation_img_extension = in_array($_FILES["faculty_image"]['type'], $img_types);

    if($validation_img_extension)
    {
        if(file_exists("upload/".$_FILES['faculty_image']['name']))
        {
            $store = $_FILES['faculty_image']['name'];
            $_SESSION['status'] = "Image already exits. '.$store' ";
            header('Location: faculty.php');
        }
        else
        {
             $query = "INSERT INTO faculty (name,design,descs,images) VALUES ('$name','$design','$descs','$images')";
            $query_run = mysqli_query($con, $query);
                    
            if($query_run)
                {
                // echo "Saved";
                move_uploaded_file($_FILES['faculty_image']['tmp_name'], "upload/".$_FILES['faculty_image']['name']);
                $_SESSION['success'] = "Faculty Added.";
                header('Location: faculty.php');
                }
                else 
                {
                $_SESSION['status'] = "Faculty is NOT Added.";
                header('Location: faculty.php');  
                }
        }

    }
    else
    {
        $_SESSION['status'] = "Only PNG, JPG, JPEG images are allowed.";
        header('Location: faculty.php'); 
    }

}
        





//CODE FOR FACULTY REGISTRATION UPDATE
if(isset($_POST['faculty_update_btn']))
{
    $id = $_POST['edit_id'];
    $name = $_POST['edit_name'];
    $design = $_POST['edit_design'];
    $descs = $_POST['edit_descs'];

    $images = $_FILES['faculty_image']['name'];

        $faculty_query ="SELECT * FROM faculty WHERE id='$id' ";
        $faculty_query_run =mysqli_query($con, $faculty_query);
        foreach ($faculty_query_run as $fa_row) 
        {     
            if($images == NULL)
            {
                // update with existing image
                $image_data =$fa_row['images'];
            }
            else
            {
                // update with new image and delete with old image.
             if($img_path="upload/" .$fa_row['images'])
                {
                    unlink($img_path);
                    $image_data =$images;
                }
        }

    }
    

    $query = "UPDATE faculty SET name='$name', design='$design', descs='$descs', images='$image_data' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
        {
            if($images == NULL)
            {
                // update with exiting image.           
            $_SESSION['success'] = "Faculty update with existing image.";
            header('Location: faculty.php');
            }
            else
            {
            // update with new image and delete with old image.

            }
            move_uploaded_file($_FILES['faculty_image']['tmp_name'], "upload/".$_FILES['faculty_image']['name']);
            $_SESSION['success'] = "Faculty Data is Updated";
            header('Location: faculty.php');
        }
        else
        {
             $_SESSION['status'] = "Faculty Data is NOT updated";
            header('Location: faculty.php');
        }

 }





//CODE FOR FACULTY REGISTRATION DELETE
if(isset($_POST['faculty_delete_btn']))
{
    $id = $_POST['delete_id'];

    $check_query = "SELECT * FROM faculty WHERE id='$id' ";
    $query_run = mysqli_query($con, $check_query);
    foreach ($query_run as $rows)
    {
       $row['images'];
       if($img_path = "upload/".$rows['images'])
       {
            $query = "DELETE FROM faculty WHERE id='$id' ";
            $query_run = mysqli_query($con, $query);

            if($query_run)
            {
                unlink($img_path);
                $_SESSION['success'] = "Faculty Data is Deleted";
                header('Location: faculty.php');
            }
            else
            {
            $_SESSION['status'] = "Faculty Data is NOT Deleted";
            header('Location: faculty.php');
            }
       }
       else
       {

       }
    }
   
}





//CODE FOR FACULTY REGISTRATION SEARCH DATA
if(isset($_POST['search_data']))
{
    $id = $_POST['id'];
    $visible = $_POST['visible'];

    $query = "UPDATE faculty SET visible='$visible' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);
      
}






//CODE FOR FACULTY REGISTRATION DELETE MULTIPLE DATA
if(isset($_POST['delete_multiple_btn']))
{
    $id = "1";

    $query = "DELETE FROM faculty WHERE visible='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Faculty Data is Deleted";
        header('Location: faculty.php');
    }
    else
    {
        $_SESSION['status'] = "Faculty Data is NOT Deleted";
        header('Location: faculty.php');
    }
       
}





//CODE FOR DEPARTMENT REGISTRATION
if(isset($_POST['dept_save']))
{
    $name = $_POST['name'];
    $descs = $_POST['descs'];
    $images = $_FILES['dept_image']['name'];    

    
     if(file_exists("upload/department/".$_FILES['dept_image']['name']))
        {
            $store = $_FILES['dept_image']['name'];
            $_SESSION['status'] = "Image already exits. '.$store' ";
            header('Location: department.php');
        }
        else
        {
             $query = "INSERT INTO dept_category (name,descs,images) VALUES ('$name','$descs','$images')";
            $query_run = mysqli_query($con, $query);
                    
            if($query_run)
                {
                // echo "Saved";
                move_uploaded_file($_FILES['dept_image']['tmp_name'], "upload/department/".$_FILES['dept_image']['name']);
                $_SESSION['success'] = "Department Category Added.";
                header('Location: department.php');
                }
                else 
                {
                $_SESSION['status'] = "Department Category is NOT Added.";
                header('Location: department.php');  
                }
        }

}
   




//CODE FOR DEPARTMENT CATEGORY REGISTRATION UPDATE
if(isset($_POST['dept_cate_update']))
{
    $id = $_POST['edit_id'];
    $name = $_POST['edit_name'];
    $descs = $_POST['edit_descs'];

    $images = $_FILES['dept_image']['name'];

  
    $query = "UPDATE dept_category SET name='$name', descs='$descs', images='$images' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
        {
            
            move_uploaded_file($_FILES['dept_image']['tmp_name'], "upload/department/".$_FILES['dept_image']['name']);
            $_SESSION['success'] = "Department Category is Updated";
            header('Location: department.php');
        }
        else
        {
             $_SESSION['status'] = "Department Category is NOT updated";
            header('Location: department.php');
        }

 }





//CODE FOR DEPARTMENT CATEGORY REGISTRATION DELETE
  if(isset($_POST['dept_cate_deletebtn']))
{
    $id = $_POST['delete_id'];

            $query = "DELETE FROM dept_category WHERE id='$id' ";
            $query_run = mysqli_query($con, $query);

            if($query_run)
            {
                
                $_SESSION['success'] = "Department Category is Deleted";
                header('Location: department.php');
            }
            else
            {
            $_SESSION['status'] = "Department Category is NOT Deleted";
            header('Location: department.php');
            }
} 





//CODE FOR DEPARTEMENT CATEGORY LIST
if(isset($_POST['dept_list_save']))
{
    $dept_id = $_POST['dept_cate_id'];
    $name = $_POST['name'];
    $descs = $_POST['descs'];
    $section = $_POST['section'];

    $query = "INSERT INTO dept_category_list (dept_cate_id,name,descs,section) VALUES ('$dept_id','$name','$descs','$section')";
    $query_run = mysqli_query($con, $query);
            
    if($query_run)
        {
        // echo "Saved";
        $_SESSION['success'] = "Department Category List is Added.";
        header('Location: department_list.php');
        }
        else 
        {
        $_SESSION['status'] = "Deparment Category List is NOT Added.";
        header('Location: department_list.php');  
        }
}





//CODE FOR DEPARTEMENT CATEGORY LIST UPDATE
if(isset($_POST['dept_catelist_update']))
{
    $updateing_id = $_POST['updateing_id'];
    $dept_cate_id = $_POST['dept_cate_id'];
    $name = $_POST['name'];
    $descs = $_POST['descs'];
    $section = $_POST['section'];

    $query = "UPDATE dept_category_list SET dept_cate_id='$dept_cate_id', name='$name', descs='$descs', section='$section' WHERE id='$updateing_id' ";
    $query_run = mysqli_query($con, $query);
            
    if($query_run)
        {
        $_SESSION['success'] = "Department Category List is Updated.";
        header('Location: department_list.php');
        }
        else 
        {
        $_SESSION['status'] = "Deparment Category List is NOT Updated.";
        header('Location: department_list.php');  
        }
}





//CODE FOR DEPARTEMENT CATEGORY LIST DELETE
if(isset($_POST['dept_catelist_deletebtn']))
{
    $delete_id = $_POST['delete_id'];

    $query = "DELETE FROM dept_category_list WHERE id='$delete_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Department Category-List is Deleted";
        header('Location: department_list.php');
    }
    else
    {
        $_SESSION['status'] = "Department Category-List is NOT Deleted";
        header('Location: department_list.php');
    }       
}

?>