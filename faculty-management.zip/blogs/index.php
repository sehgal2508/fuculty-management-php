<?php 
include('includes/header.php');
include('includes/navbar.php');
include('includes/Carousel.php');
?>

<div class="containter py-5">
  <div class="row">

    <div class="col-md-4">      
      <div class="card">
          <div class="card-body">
          <h5 class="card-title">Our Vision</h5>
          <p> Hello, This is my Web-Site.</p>
          </div>
      </div>
    </div>   

     <div class="col-md-4">      
          <div class="card">
              <div class="card-body">
              <h5 class="card-title">Our Mission</h5>
              <p> Hello, This is my Web-Site.</p>
              </div>
          </div>
        </div> 

      <div class="col-md-4">      
          <div class="card">
              <div class="card-body">
              <h5 class="card-title">Our Values</h5>
              <p> Hello, This is my Web-Site.</p>
              </div>
          </div>
        </div> 

  </div>  
</div>


<div class="containter py-5">
  <div class="row">

    <div class="col-md-8">
      <div class="card">
        <div class="card-body">
          <h2>Welcome to my college website</h2>
          <hr>
          <p> This is my web Tutorials making.</p>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <h2>Notice</h2>
          <hr>
          <p> This is my web Tutorials making.</p>
        </div>
      </div>
    </div>

    </div>
  </div>
</div>



<?php 
include('includes/footer.php');
?>