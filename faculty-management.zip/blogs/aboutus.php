<?php include('includes/header.php'); ?>
<?php include('includes/navbar.php'); ?>

<div class="container py-5">
	<div class="row py-3">
		<div class="col-md-8">

			<div class="card">
			  <img  src="img/1.jpg" class="card-img-top" alt="...">
			  <div class="card-body">
			  	<?php
			  	   include('dbconfig.php');
			  	   $query = "SELECT * FROM aboutus";
			  	   $query_run = mysqli_query($con, $query);

			  	   if(mysqli_num_rows($query_run) > 0)
			  	   	{
			  	   		foreach ($query_run as $row)
			  	   		{
			  	   			?>
			  	  		

					    <h4 class="card-title"><?php echo $row['title']; ?></h4>
					    <h5><?php echo $row['subtitle']; ?></h5>
					    <p class="card-text"><?php echo $row['descs']; ?></p>
					    <a href="<?php echo $row['links']; ?>" class="btn btn-primary">Go My College Website</a>
			    <?php
			  	   		}
			  		}
			  		else
			  		{
			  		echo "No Record found !";
			  		}

			  	?>
			  </div>
			</div>

		</div>
		<div class="col-md-4">
			<div class="card">
			    <div class="card-body">
			    <h5 class="card-title">Notice</h5>
			    <p class="card-text"> This is web it toturial for  creatin a BLOG in PHP.</p>
			    <a href="#" class="btn btn-primary">Go somewhere</a>
			  </div>
			</div>
			<hr>
			<div class="card">
			    <div class="card-body">
			    <h5 class="card-title">Notice</h5>
			    <p class="card-text"> This is web it toturial for  creatin a BLOG in PHP.</p>
			    <a href="#" class="btn btn-primary">Go somewhere</a>
			  </div>
			</div>
			<hr>

		</div>
	</div>
</div>







<?php include('includes/footer.php'); ?>